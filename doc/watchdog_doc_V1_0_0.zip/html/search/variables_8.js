var searchData=
[
  ['start_80',['start',['../structwdt__ctrl__t.html#aeac2ee08de24c8c37cdb5986da5cc7e3',1,'wdt_ctrl_t']]],
  ['stats_81',['stats',['../structwdt__ctrl__t.html#ac75dd3f73d5520470401d750c5c3c5b2',1,'wdt_ctrl_t']]],
  ['sum_82',['sum',['../structwdt__stats__t.html#a08a536423d95185638f7b2c096f56445',1,'wdt_stats_t']]]
];
