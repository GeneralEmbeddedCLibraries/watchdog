var searchData=
[
  ['num_5fof_5freports_12',['num_of_reports',['../structwdt__stats__t.html#a369bded989481109e19eaafa8ed3da5a',1,'wdt_stats_t']]],
  ['num_5fof_5fsamp_13',['num_of_samp',['../structwdt__stats__t.html#a9637d983bd78ac8c3eab5ff58d6e96f8',1,'wdt_stats_t']]]
];
