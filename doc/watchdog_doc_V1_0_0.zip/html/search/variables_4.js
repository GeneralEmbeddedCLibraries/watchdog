var searchData=
[
  ['max_74',['max',['../structwdt__stats__t.html#aaa6bdf5e63b435028f8c35f188235027',1,'wdt_stats_t']]],
  ['min_75',['min',['../structwdt__stats__t.html#ac42315e17fe8025aab0cedf82b46ea3e',1,'wdt_stats_t']]]
];
