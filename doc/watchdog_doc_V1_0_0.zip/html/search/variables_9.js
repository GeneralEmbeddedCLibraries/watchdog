var searchData=
[
  ['time_83',['time',['../structwdt__stats__t.html#a50b70e692a70f2ef489bbdcf973d9b93',1,'wdt_stats_t']]],
  ['timeout_84',['timeout',['../structwdt__cfg__t.html#a19832730fdbe87a79e0deb6cf74a8c06',1,'wdt_cfg_t']]],
  ['trace_85',['trace',['../structwdt__ctrl__t.html#a68deadcfc188d749fb53bd549f4e12bb',1,'wdt_ctrl_t']]]
];
