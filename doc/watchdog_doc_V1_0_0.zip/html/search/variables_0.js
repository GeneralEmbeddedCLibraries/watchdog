var searchData=
[
  ['avg_68',['avg',['../structwdt__stats__t.html#a343c72085b9cf93b05dfc6da52d54118',1,'wdt_stats_t']]]
];
