var annotated_dup =
[
    [ "wdt_cfg_t", "structwdt__cfg__t.html", "structwdt__cfg__t" ],
    [ "wdt_ctrl_t", "structwdt__ctrl__t.html", "structwdt__ctrl__t" ],
    [ "wdt_stats_t", "structwdt__stats__t.html", "structwdt__stats__t" ]
];