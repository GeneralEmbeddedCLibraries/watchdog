var wdt_8h =
[
    [ "WDT_VER_DEVELOP", "group___w_a_t_c_h_d_o_g___a_p_i.html#ga51ecc0ec2bd628ab48bbb5e0904c9c8e", null ],
    [ "WDT_VER_MAJOR", "group___w_a_t_c_h_d_o_g___a_p_i.html#ga61ad4853a1f0ffb56b13a54c7a239b04", null ],
    [ "WDT_VER_MINOR", "group___w_a_t_c_h_d_o_g___a_p_i.html#ga27523a6a3daf00401f5e465e3ab48f0a", null ],
    [ "wdt_status_t", "group___w_a_t_c_h_d_o_g___a_p_i.html#ga46c1d04f78b75ad1ad21314cac574935", [
      [ "eWDT_OK", "group___w_a_t_c_h_d_o_g___a_p_i.html#gga46c1d04f78b75ad1ad21314cac574935adc4ac480b026f672054e6bb8c495c6bf", null ],
      [ "eWDT_ERROR", "group___w_a_t_c_h_d_o_g___a_p_i.html#gga46c1d04f78b75ad1ad21314cac574935a684178070b1675bc7bd5d23e545858ea", null ],
      [ "eWDT_ERROR_INIT", "group___w_a_t_c_h_d_o_g___a_p_i.html#gga46c1d04f78b75ad1ad21314cac574935ad8e3a3d1ed3fe53e303783abf352acc2", null ],
      [ "eWDT_ERROR_CFG", "group___w_a_t_c_h_d_o_g___a_p_i.html#gga46c1d04f78b75ad1ad21314cac574935ae3645634064231122235a775b7e9099d", null ]
    ] ],
    [ "wdt_hndl", "group___w_a_t_c_h_d_o_g___a_p_i.html#ga16bd395c6345ee665ca0a94b15736f57", null ],
    [ "wdt_init", "group___w_a_t_c_h_d_o_g___a_p_i.html#ga3da7c26592b98ebf5d55ce0979e77f73", null ],
    [ "wdt_is_init", "group___w_a_t_c_h_d_o_g___a_p_i.html#ga77bd18f7fbb2c006c5967390655120f2", null ],
    [ "wdt_pre_reset_isr_callback", "group___w_a_t_c_h_d_o_g___a_p_i.html#ga3a2ed5156e9f159d7217232cbbc5c0cd", null ],
    [ "wdt_start", "group___w_a_t_c_h_d_o_g___a_p_i.html#ga2cc37852e0182d86040dc71d83de7217", null ],
    [ "wdt_task_report", "group___w_a_t_c_h_d_o_g___a_p_i.html#gafd651f33ecbc4c3c08b19c1535ed7dd3", null ]
];