var modules =
[
    [ "WATCHDOG", "group___w_a_t_c_h_d_o_g.html", "group___w_a_t_c_h_d_o_g" ],
    [ "WATCHDOG_API", "group___w_a_t_c_h_d_o_g___a_p_i.html", "group___w_a_t_c_h_d_o_g___a_p_i" ]
];