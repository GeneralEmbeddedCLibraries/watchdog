var structwdt__cfg__t =
[
    [ "enable", "structwdt__cfg__t.html#aed2a3645d8b1fbd97319872eb6039fb3", null ],
    [ "p_name", "structwdt__cfg__t.html#ab5d1a7a7f9efa2a293786fadccd0682b", null ],
    [ "timeout", "structwdt__cfg__t.html#a19832730fdbe87a79e0deb6cf74a8c06", null ]
];