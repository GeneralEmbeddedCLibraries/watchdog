var wdt_8c =
[
    [ "WDT_TRACE_BUFFER_SIZE", "group___w_a_t_c_h_d_o_g.html#gae70d1ac8b9e988b839951f0a2735adec", null ],
    [ "wdt_check_task_reports", "group___w_a_t_c_h_d_o_g.html#ga79b1a708a11b028e9b2fbac47ccb2e9e", null ],
    [ "wdt_hndl", "group___w_a_t_c_h_d_o_g___a_p_i.html#ga16bd395c6345ee665ca0a94b15736f57", null ],
    [ "wdt_init", "group___w_a_t_c_h_d_o_g___a_p_i.html#ga3da7c26592b98ebf5d55ce0979e77f73", null ],
    [ "wdt_is_init", "group___w_a_t_c_h_d_o_g___a_p_i.html#ga77bd18f7fbb2c006c5967390655120f2", null ],
    [ "wdt_kick_hndl", "group___w_a_t_c_h_d_o_g.html#ga132a0d49105b14ee498e87010ff50e2d", null ],
    [ "wdt_pre_reset_isr_callback", "group___w_a_t_c_h_d_o_g___a_p_i.html#ga3a2ed5156e9f159d7217232cbbc5c0cd", null ],
    [ "wdt_start", "group___w_a_t_c_h_d_o_g___a_p_i.html#ga2cc37852e0182d86040dc71d83de7217", null ],
    [ "wdt_stats_calc", "group___w_a_t_c_h_d_o_g.html#ga6e2663f0cebb83252874600624849971", null ],
    [ "wdt_stats_clear_counts", "group___w_a_t_c_h_d_o_g.html#gac6412fc0bfcc25c7f384df133e3c9107", null ],
    [ "wdt_stats_clear_timings", "group___w_a_t_c_h_d_o_g.html#ga0f532617d0bd636b3a3ba9e4a277f5ac", null ],
    [ "wdt_stats_count_hndl", "group___w_a_t_c_h_d_o_g.html#gacba0768b4be3231514a18eed1e223a03", null ],
    [ "wdt_stats_init", "group___w_a_t_c_h_d_o_g.html#ga120d380454f1a31803b639c459e36b26", null ],
    [ "wdt_task_report", "group___w_a_t_c_h_d_o_g___a_p_i.html#gafd651f33ecbc4c3c08b19c1535ed7dd3", null ],
    [ "wdt_trace_buffer_put", "group___w_a_t_c_h_d_o_g.html#ga18cfa5f7be3a76cb3eeaa00562045eb7", null ],
    [ "g_wdt_ctrl", "group___w_a_t_c_h_d_o_g.html#gade2d53e5f840335f15ba64f00d365780", null ],
    [ "gb_is_init", "group___w_a_t_c_h_d_o_g.html#ga7aa5c1c01a25e6125e4771126667c385", null ],
    [ "gp_wdt_cfg_table", "group___w_a_t_c_h_d_o_g.html#gad1614b6f14bc6c41f8a1a384aa24a816", null ]
];