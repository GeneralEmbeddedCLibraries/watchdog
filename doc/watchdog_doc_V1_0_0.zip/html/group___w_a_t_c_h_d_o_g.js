var group___w_a_t_c_h_d_o_g =
[
    [ "wdt_stats_t", "structwdt__stats__t.html", [
      [ "avg", "structwdt__stats__t.html#a343c72085b9cf93b05dfc6da52d54118", null ],
      [ "max", "structwdt__stats__t.html#aaa6bdf5e63b435028f8c35f188235027", null ],
      [ "min", "structwdt__stats__t.html#ac42315e17fe8025aab0cedf82b46ea3e", null ],
      [ "num_of_reports", "structwdt__stats__t.html#a369bded989481109e19eaafa8ed3da5a", null ],
      [ "num_of_samp", "structwdt__stats__t.html#a9637d983bd78ac8c3eab5ff58d6e96f8", null ],
      [ "sum", "structwdt__stats__t.html#a08a536423d95185638f7b2c096f56445", null ],
      [ "time", "structwdt__stats__t.html#a50b70e692a70f2ef489bbdcf973d9b93", null ]
    ] ],
    [ "wdt_ctrl_t", "structwdt__ctrl__t.html", [
      [ "last_kick", "structwdt__ctrl__t.html#a36892cc4e9e883ee3b0496648cff8a4e", null ],
      [ "report_timestamp", "structwdt__ctrl__t.html#a961c0d798b21ad7a3010a59d2e4f2beb", null ],
      [ "start", "structwdt__ctrl__t.html#aeac2ee08de24c8c37cdb5986da5cc7e3", null ],
      [ "stats", "structwdt__ctrl__t.html#ac75dd3f73d5520470401d750c5c3c5b2", null ],
      [ "trace", "structwdt__ctrl__t.html#a68deadcfc188d749fb53bd549f4e12bb", null ],
      [ "valid", "structwdt__ctrl__t.html#a4ffc84e5bf837cbbee62858d37acf955", null ]
    ] ],
    [ "WDT_TRACE_BUFFER_SIZE", "group___w_a_t_c_h_d_o_g.html#gae70d1ac8b9e988b839951f0a2735adec", null ],
    [ "wdt_check_task_reports", "group___w_a_t_c_h_d_o_g.html#ga79b1a708a11b028e9b2fbac47ccb2e9e", null ],
    [ "wdt_kick_hndl", "group___w_a_t_c_h_d_o_g.html#ga132a0d49105b14ee498e87010ff50e2d", null ],
    [ "wdt_stats_calc", "group___w_a_t_c_h_d_o_g.html#ga6e2663f0cebb83252874600624849971", null ],
    [ "wdt_stats_clear_counts", "group___w_a_t_c_h_d_o_g.html#gac6412fc0bfcc25c7f384df133e3c9107", null ],
    [ "wdt_stats_clear_timings", "group___w_a_t_c_h_d_o_g.html#ga0f532617d0bd636b3a3ba9e4a277f5ac", null ],
    [ "wdt_stats_count_hndl", "group___w_a_t_c_h_d_o_g.html#gacba0768b4be3231514a18eed1e223a03", null ],
    [ "wdt_stats_init", "group___w_a_t_c_h_d_o_g.html#ga120d380454f1a31803b639c459e36b26", null ],
    [ "wdt_trace_buffer_put", "group___w_a_t_c_h_d_o_g.html#ga18cfa5f7be3a76cb3eeaa00562045eb7", null ],
    [ "g_wdt_ctrl", "group___w_a_t_c_h_d_o_g.html#gade2d53e5f840335f15ba64f00d365780", null ],
    [ "gb_is_init", "group___w_a_t_c_h_d_o_g.html#ga7aa5c1c01a25e6125e4771126667c385", null ],
    [ "gp_wdt_cfg_table", "group___w_a_t_c_h_d_o_g.html#gad1614b6f14bc6c41f8a1a384aa24a816", null ]
];