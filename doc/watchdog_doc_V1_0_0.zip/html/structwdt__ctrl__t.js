var structwdt__ctrl__t =
[
    [ "last_kick", "structwdt__ctrl__t.html#a36892cc4e9e883ee3b0496648cff8a4e", null ],
    [ "report_timestamp", "structwdt__ctrl__t.html#a961c0d798b21ad7a3010a59d2e4f2beb", null ],
    [ "start", "structwdt__ctrl__t.html#aeac2ee08de24c8c37cdb5986da5cc7e3", null ],
    [ "stats", "structwdt__ctrl__t.html#ac75dd3f73d5520470401d750c5c3c5b2", null ],
    [ "trace", "structwdt__ctrl__t.html#a68deadcfc188d749fb53bd549f4e12bb", null ],
    [ "valid", "structwdt__ctrl__t.html#a4ffc84e5bf837cbbee62858d37acf955", null ]
];