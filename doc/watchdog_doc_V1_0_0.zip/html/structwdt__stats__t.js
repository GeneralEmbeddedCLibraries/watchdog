var structwdt__stats__t =
[
    [ "avg", "structwdt__stats__t.html#a343c72085b9cf93b05dfc6da52d54118", null ],
    [ "max", "structwdt__stats__t.html#aaa6bdf5e63b435028f8c35f188235027", null ],
    [ "min", "structwdt__stats__t.html#ac42315e17fe8025aab0cedf82b46ea3e", null ],
    [ "num_of_reports", "structwdt__stats__t.html#a369bded989481109e19eaafa8ed3da5a", null ],
    [ "num_of_samp", "structwdt__stats__t.html#a9637d983bd78ac8c3eab5ff58d6e96f8", null ],
    [ "sum", "structwdt__stats__t.html#a08a536423d95185638f7b2c096f56445", null ],
    [ "time", "structwdt__stats__t.html#a50b70e692a70f2ef489bbdcf973d9b93", null ]
];